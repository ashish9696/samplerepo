from flask import Flask, make_response, request, flash, render_template
import io
import csv
import pandas as pd
import os
import boto3

app = Flask(__name__, template_folder='./html')
app.secret_key = "abc" 

def transform(text_file_contents):
    return text_file_contents.replace("=", ",")

s3 = boto3.resource(
    service_name='s3',
    region_name='us-west-1',
    aws_access_key_id='AKIAV3QP7XCBTIWDWXGW',
    aws_secret_access_key='+u9myRBWtz87BFQIfpHmQbE2O6gjOi2YahpQg7K1'
)
@app.route('/')
def form():
    '''return """
        <html>
            <body>
                <h1>Upload Independent and dependent dataset files</h1>

                <form action="/transform" method="post" enctype="multipart/form-data">
                    <input type="file" name="external_data" />
                    <input type="file" name="internal_data" />
                    <input type="submit" />
                </form>
            </body>
        </html>
    """'''
    return render_template("index.html")

@app.route('/transform', methods=["POST"])
def transform_view():
    f = request.files['external_data']
    filename = f.filename
    f.save(os.path.join("/home/ec2-user/jbs-pilgrims/data", "external_data.csv"))
    #s3.Bucket('jbs-demand-forecasting').upload_file(Filename=os.path.join("/home/ec2-user/jbs-pilgrims/data", f.filename), Key='inputs/'+f.filename)
    f = request.files['internal_data']
    filename = f.filename
    f.save(os.path.join("/home/ec2-user/jbs-pilgrims/data", "internal_data.csv"))
    #s3.Bucket('jbs-demand-forecasting').upload_file(Filename=os.path.join("/home/ec2-user/jbs-pilgrims/data", f.filename), Key='inputs/'+f.filename)
    flash("you have successfully uploaded")
    return render_template("index2.html")#'''<script type="text/javascript">alert("Data received");</script>  
#''' 
#"file uploaded successfully."

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=3001, debug=False)
