python3 lambda_function.py
