import sys
import os
from sklearn.linear_model import LinearRegression

import pandas as pd
import numpy as np
from sklearn import metrics
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import sklearn
from sklearn import linear_model
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor

# Using Skicit-learn to split data into training and testing sets
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
# Import the model we are using
from sklearn.ensemble import RandomForestRegressor

import xgboost as xgb
from xgboost import XGBRegressor

filtercols = ['CONVENTIONALFRESH/FROZEN/PREPARED_ActivityIndex', 'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate',
        'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate','Pork_Activity Index','Pork_Feature Rate',
 'Pork_Special Rate',
 'Beef_Activity Index','Beef_Feature Rate',
 'Beef_Special Rate',
 'Super Bowl',
 'March Madness 1',
 'March Madness 2',
 'March Madness 3',
 'March Madness 4',
 'NBA Finals','Stanley Cup Finals',
 'Independence Day',
 'Labor Day',
 'World Series',
 'Thanksgiving',
'CalendarWeek','CalWeekNbr',
 'School End 1','School End 2','School End 3',
 'School Start 1', 'School Start 2','School Start 3']
 
colsdict = {'deli': {'marchmad': ['March Madness 1',
'March Madness 2',
'March Madness 3',
'March Madness 4',
'March Madness 1-1',
'March Madness 1-2',
'March Madness 2-1',
'March Madness 2-2',
'March Madness 3-1',
'March Madness 3-2',
'March Madness 4-1'],
'superb': ['Super Bowl-1', 'Super Bowl'],
'schools': ['School End 1',
'School End 2',
'School End 3',
'School End 1-1',
'School End 1-2',
'School End 1-3',
'School End 2-1',
'School End 2-2',
'School End 3-1'],
'indpday': ['Independence Day-2','Independence Day-1', 'Independence Day'],
'others': ['World Series'],
'external_features': ['CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-1',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-1',
'Pork_Special Rate','Pork_Special Rate-3','Pork_Special Rate-2','Pork_Special Rate-1',
'Beef_Special Rate','Beef_Special Rate-3','Beef_Special Rate-2','Beef_Special Rate-1']},
'consumer': {'marchmad': ['March Madness 1',
'March Madness 2',
'March Madness 3',
'March Madness 4',
'March Madness 1-1',
'March Madness 2-3',
'March Madness 2-2',
'March Madness 2-1',
'March Madness 3-1',
'March Madness 4-1'],
'superb': ['Super Bowl-1', 'Super Bowl'],
'indpday': ['Independence Day-1', 'Independence Day'],
'others': ['World Series',
'School End 1',
'School End 2',
'School End 3',
'Thanksgiving'],
'external_features': ['CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-1',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-1',
'Pork_Special Rate','Pork_Special Rate-3','Pork_Special Rate-2','Pork_Special Rate-1',
'Beef_Special Rate','Beef_Special Rate-3','Beef_Special Rate-2','Beef_Special Rate-1',
'Pork_Feature Rate','Pork_Feature Rate-3','Pork_Feature Rate-2','Pork_Feature Rate-1',
'Beef_Feature Rate','Beef_Feature Rate-3','Beef_Feature Rate-2','Beef_Feature Rate-1']},
'distributor': {'marchmad': ['March Madness 1',
'March Madness 2',
'March Madness 3',
'March Madness 4',
'March Madness 1-3',
'March Madness 1-2',
'March Madness 1-1',
'March Madness 2-1',
'March Madness 2-2',                             
'March Madness 3-1',
'March Madness 3-2',                             
'March Madness 4-1'],
'superb': ['Super Bowl-4','Super Bowl-3','Super Bowl-2','Super Bowl-1', 'Super Bowl'],
'schools': ['School End 1',
'School End 2',
'School End 3',
'School End 1-5','School End 1-4','School End 1-3','School End 1-2','School End 1-1',
'School End 2-4','School End 2-3','School End 2-2','School End 2-1',
'School End 3-3','School End 3-2','School End 3-1'],
'schools1': ['School Start 1',
'School Start 2',
'School Start 1-7','School Start 1-6','School Start 1-5','School Start 1-4','School Start 1-3',
'School Start 1-2','School Start 1-1'],
'indpday': ['Independence Day-4','Independence Day-3','Independence Day-2','Independence Day-1', 'Independence Day'],
'others': ['World Series', 'Thanksgiving', 'School Start 3'],
'external_features': ['CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-1',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-1',
'Pork_Special Rate','Pork_Special Rate-3','Pork_Special Rate-2','Pork_Special Rate-1',
'Beef_Special Rate','Beef_Special Rate-3','Beef_Special Rate-2','Beef_Special Rate-1',
'Pork_Feature Rate','Pork_Feature Rate-3','Pork_Feature Rate-2','Pork_Feature Rate-1',
'Beef_Feature Rate','Beef_Feature Rate-3','Beef_Feature Rate-2','Beef_Feature Rate-1']},
'schools': {'schools': ['School End 1',
'School End 2',
'School End 3',
'School End 1-10','School End 1-9','School End 1-8','School End 1-7','School End 1-6',
'School End 1-5','School End 1-4','School End 1-3','School End 1-2','School End 1-1',
'School End 2-4','School End 2-3','School End 2-2','School End 2-1',
'School End 3-3','School End 3-2','School End 3-1'],
'schools1': ['School Start 1',
'School Start 2',
'School Start 3',
'School Start 1-8','School Start 1-7','School Start 1-6','School Start 1-5',
'School Start 1-4','School Start 1-3','School Start 1-2','School Start 1-1',
'School Start 3-6','School Start 3-5','School Start 3-4','School Start 3-3',
'School Start 3-2','School Start 3-1'],
'others': ['World Series', 'Thanksgiving', 'Independence Day']}}


def lagconfig(df, res):
    for k in res.keys():
        tok = res[k]
        while(tok!=0):
            df[k+str(tok)] = df[k].shift(tok)
            if(tok<0):
                tok=tok+1
            else:
                tok=tok-1
    return df
    
def get_external_lag(df):
    df.sort_values(by=['CalendarWeek','CalWeekNbr'],inplace=True)
    events = ['Super Bowl','March Madness 1','March Madness 2','March Madness 3','March Madness 4',
     'NBA Finals','Stanley Cup Finals','Independence Day','Labor Day', 'World Series','Thanksgiving']
    res = {}
    for k in filtercols:
        res[k] = 0
    res['Super Bowl'] = -4
    res['CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate'] = -3
    res['CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate'] = -3
    res['Beef_Activity Index'] = -3
    res['Beef_Special Rate'] = -3
    res['Beef_Feature Rate'] = -3
    res['Pork_Activity Index'] = -3
    res['Pork_Special Rate'] = -3
    res['Pork_Feature Rate'] = -3
    res['Independence Day'] = -4
    res['March Madness 1'] = -3
    res['March Madness 2'] = -3
    res['March Madness 3'] = -2
    res['March Madness 4'] = -1
    res['School End 1'] = -10
    res['School End 2'] = -4
    res['School End 3'] = -3
    res['School Start 1'] = -8
    res['School Start 2'] = -7
    res['School Start 3'] = -6
    return lagconfig(df, res),res
    
def sumrow(x,listcol):
    res = 0
    for l in listcol:
        res += x[l]
    return res
    


def predictor(dftemp,res,SKUNUM, sku_channel, lag_predict):
    subchannel = sku_channel[sku_channel['SAP_SKU']==SKUNUM]['Sub-Channel'].values[0].lower()
    ### Change 1 ***********
    x=30   ##### No of external features.
    dftemp.iloc[:, -(int(x)):] = dftemp.iloc[:, -(int(x)):].fillna(method='ffill')
    #df_test = dftemp.iloc[-(int(lag_predict)):]
    dftemp = dftemp[dftemp['SAP_SKU']==SKUNUM]
    dftemp.fillna(method='ffill', inplace=True)
    df_test = dftemp.iloc[-(int(lag_predict)):]
    df = dftemp.copy()
    df1 = df_test.copy()
    ##### ********************************** added demand>0 filter ********************************* 
    df = df[df['Weighted Sales Target Var']>0]
    subchannel_cols = ['Weighted Sales Target Var']
    colkeys = [*colsdict[subchannel]]#.keys()
    #print('ColKeys:',colkeys)
    for c in colkeys[:-2]:
        df[c] = 0
        df[c] = df.apply(lambda x:sumrow(x,colsdict[subchannel][c]),axis=1) ###Lag variable###
        subchannel_cols.extend([c])
    subchannel_cols.extend(colsdict[subchannel][colkeys[-1]])
    subchannel_cols.extend(colsdict[subchannel][colkeys[-2]])
    
    ######******** Change 2 *********************
    ######************************ Trail lag for Test data **********************
    subchannel_cols1 = ['Weighted Sales Target Var']
    colkeys1 = [*colsdict[subchannel]]#.keys()
    print('ColKeys:',colkeys1)
    for c in colkeys1[:-2]:
        df1[c] = 0
        df1[c] = df1.apply(lambda x:sumrow(x,colsdict[subchannel][c]),axis=1) ###Lag variable###
        subchannel_cols1.extend([c])
    subchannel_cols1.extend(colsdict[subchannel][colkeys1[-1]])
    subchannel_cols1.extend(colsdict[subchannel][colkeys1[-2]])
    
    ####************* Change 3 ************************
    ####********************** train test split new logic*******************************************************************
    df_train=df.iloc[:-(int(lag_predict))]  #df_train = df.dropna(subset = ['Weighted Sales Target Var'])
    df_train.fillna(method='ffill', inplace=True)
    train_features = df_train[subchannel_cols[1:]]
    train_labels = df_train[subchannel_cols[0]]
    #df_test = df1
    test_features = df1[subchannel_cols1[1:]]
    #test_features.fillna(method='ffill', inplace=True)
    
    ####### RF model ###############
    rf = RandomForestRegressor(n_estimators = 1000, random_state = 42)
    rf.fit(train_features, train_labels);
    test_features.fillna(0,inplace=True)
    predictions = rf.predict(test_features)
    importances = list(rf.feature_importances_)
    feature_importances = [(feature, round(importance, 2)) for feature, importance in zip(subchannel_cols[1:], importances)]
    feature_importances = sorted(feature_importances, key = lambda x: x[1], reverse = True)
    [print('Variable: {:20} Importance: {}'.format(*pair)) for pair in feature_importances];
    
    ####### XGB model ##################
    xgb = XGBRegressor(n_estimators=1000, eta=0.1, subsample=0.75, colsample_bytree=0.8, max_depth=7)
    xgb.fit(train_features, train_labels);
    predictions_xgb = xgb.predict(test_features)
    
    #######********** Change 4 *************************
    test_features['Pred_RF'] = predictions
    test_features['Weighted Sales Target Var'] = df_test['Weighted Sales Target Var']
    test_features['SAP_SKU'] = df_test['SAP_SKU']  ####### added sku col
    test_features['Calendar_Week_Year'] = df_test['Calendar_Week_Year']  ######### added cal year col
    test_features['SAP_SKU'].fillna(int(SKUNUM),inplace = True)          ######### assigned dynamic SKU num
    #test_features['Pred_Xgb'] = predictions_xgb
    #dfres = pd.DataFrame({'pred_RF':predictions, 'pred_XGB':predictions_xgb })
    #dfres = pd.concat([test_features,dfres], axis=1)
    dfres = test_features
    del df
    return dfres
