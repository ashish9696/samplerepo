import json
import numpy as np
import sklearn
import pandas as pd
import sys
import json

from sklearn.linear_model import LinearRegression
import boto3

from sklearn import metrics
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import sklearn
from sklearn import linear_model
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor

# Using Skicit-learn to split data into training and testing sets
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
# Import the model we are using
from sklearn.ensemble import RandomForestRegressor

import xgboost as xgb
from xgboost import XGBRegressor

from jbs_utils import *
import boto3

filtercols = ['CONVENTIONALFRESH/FROZEN/PREPARED_ActivityIndex', 'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate',
        'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate','Pork_Activity Index','Pork_Feature Rate',
 'Pork_Special Rate',
 'Beef_Activity Index','Beef_Feature Rate',
 'Beef_Special Rate',
 'Super Bowl',
 'March Madness 1',
 'March Madness 2',
 'March Madness 3',
 'March Madness 4',
 'NBA Finals','Stanley Cup Finals',
 'Independence Day',
 'Labor Day',
 'World Series',
 'Thanksgiving',
'CalendarWeek','CalWeekNbr',
 'School End 1','School End 2','School End 3',
 'School Start 1', 'School Start 2','School Start 3']
 
colsdict = {'deli': {'marchmad': ['March Madness 1',
'March Madness 2',
'March Madness 3',
'March Madness 4',
'March Madness 1-1',
'March Madness 1-2',
'March Madness 2-1',
'March Madness 2-2',
'March Madness 3-1',
'March Madness 3-2',
'March Madness 4-1'],
'superb': ['Super Bowl-1', 'Super Bowl'],
'schools': ['School End 1',
'School End 2',
'School End 3',
'School End 1-1',
'School End 1-2',
'School End 1-3',
'School End 2-1',
'School End 2-2',
'School End 3-1'],
'indpday': ['Independence Day-2','Independence Day-1', 'Independence Day'],
'others': ['World Series'],
'external_features': ['CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-1',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-1',
'Pork_Special Rate','Pork_Special Rate-3','Pork_Special Rate-2','Pork_Special Rate-1',
'Beef_Special Rate','Beef_Special Rate-3','Beef_Special Rate-2','Beef_Special Rate-1']},
'consumer': {'marchmad': ['March Madness 1',
'March Madness 2',
'March Madness 3',
'March Madness 4',
'March Madness 1-1',
'March Madness 2-3',
'March Madness 2-2',
'March Madness 2-1',
'March Madness 3-1',
'March Madness 4-1'],
'superb': ['Super Bowl-1', 'Super Bowl'],
'indpday': ['Independence Day-1', 'Independence Day'],
'others': ['World Series',
'School End 1',
'School End 2',
'School End 3',
'Thanksgiving'],
'external_features': ['CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-1',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-1',
'Pork_Special Rate','Pork_Special Rate-3','Pork_Special Rate-2','Pork_Special Rate-1',
'Beef_Special Rate','Beef_Special Rate-3','Beef_Special Rate-2','Beef_Special Rate-1',
'Pork_Feature Rate','Pork_Feature Rate-3','Pork_Feature Rate-2','Pork_Feature Rate-1',
'Beef_Feature Rate','Beef_Feature Rate-3','Beef_Feature Rate-2','Beef_Feature Rate-1']},
'distributor': {'marchmad': ['March Madness 1',
'March Madness 2',
'March Madness 3',
'March Madness 4',
'March Madness 1-3',
'March Madness 1-2',
'March Madness 1-1',
'March Madness 2-1',
'March Madness 2-2',                             
'March Madness 3-1',
'March Madness 3-2',                             
'March Madness 4-1'],
'superb': ['Super Bowl-4','Super Bowl-3','Super Bowl-2','Super Bowl-1', 'Super Bowl'],
'schools': ['School End 1',
'School End 2',
'School End 3',
'School End 1-5','School End 1-4','School End 1-3','School End 1-2','School End 1-1',
'School End 2-4','School End 2-3','School End 2-2','School End 2-1',
'School End 3-3','School End 3-2','School End 3-1'],
'schools1': ['School Start 1',
'School Start 2',
'School Start 1-7','School Start 1-6','School Start 1-5','School Start 1-4','School Start 1-3',
'School Start 1-2','School Start 1-1'],
'indpday': ['Independence Day-4','Independence Day-3','Independence Day-2','Independence Day-1', 'Independence Day'],
'others': ['World Series', 'Thanksgiving', 'School Start 3'],
'external_features': ['CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_FeatureRate-1',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-3',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-2',
'CONVENTIONALFRESH/FROZEN/PREPARED_SpecialRate-1',
'Pork_Special Rate','Pork_Special Rate-3','Pork_Special Rate-2','Pork_Special Rate-1',
'Beef_Special Rate','Beef_Special Rate-3','Beef_Special Rate-2','Beef_Special Rate-1',
'Pork_Feature Rate','Pork_Feature Rate-3','Pork_Feature Rate-2','Pork_Feature Rate-1',
'Beef_Feature Rate','Beef_Feature Rate-3','Beef_Feature Rate-2','Beef_Feature Rate-1']},
'schools': {'schools': ['School End 1',
'School End 2',
'School End 3',
'School End 1-10','School End 1-9','School End 1-8','School End 1-7','School End 1-6',
'School End 1-5','School End 1-4','School End 1-3','School End 1-2','School End 1-1',
'School End 2-4','School End 2-3','School End 2-2','School End 2-1',
'School End 3-3','School End 3-2','School End 3-1'],
'schools1': ['School Start 1',
'School Start 2',
'School Start 3',
'School Start 1-8','School Start 1-7','School Start 1-6','School Start 1-5',
'School Start 1-4','School Start 1-3','School Start 1-2','School Start 1-1',
'School Start 3-6','School Start 3-5','School Start 3-4','School Start 3-3',
'School Start 3-2','School Start 3-1'],
'others': ['World Series', 'Thanksgiving', 'Independence Day']}}

s3 = boto3.resource(
    service_name='s3',
    region_name='us-west-1',
    aws_access_key_id='AKIAV3QP7XCBTIWDWXGW',
    aws_secret_access_key='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'
)

def s3_read(AWS_S3_BUCKET, inputkey):
    s3_client = boto3.client("s3")

    response = s3_client.get_object(Bucket=AWS_S3_BUCKET, Key=inputkey)
    
    status = response.get("ResponseMetadata", {}).get("HTTPStatusCode")
    
    if status == 200:
        print(f"Successful S3 get_object response. Status - {status}")
        return response.get("Body")
    else:
        print(f"Unsuccessful S3 get_object response. Status - {status}")
    return 1


def main(sku=14570,lag_predict=9):
    #df = pd.read_csv(s3_read('jbs-demand-forecasting',"inputs/IndependentVar_weekly_i10.csv"))
    #dfsales = pd.read_csv(s3_read('jbs-demand-forecasting',"inputs/DependentVar_weekly_i9.csv"))
    df = pd.read_csv("/home/ec2-user/jbs-pilgrims/data/external_data.csv")
    dfsales = pd.read_csv("/home/ec2-user/jbs-pilgrims/data/internal_data.csv")
    sku_channel = dfsales[['SAP_SKU','Sub-Channel']]
    df = df[filtercols]
    colstouse = []
    for c in colsdict[sku_channel[sku_channel['SAP_SKU']==sku]['Sub-Channel'].values[0].lower()]:
        colstouse.extend(colsdict[sku_channel[sku_channel['SAP_SKU']==sku]['Sub-Channel'].values[0].lower()][c])
    colstouse.extend(['CalendarWeek','CalWeekNbr'])
    df,res = get_external_lag(df)
    df=df[colstouse]
    
    dfsales = dfsales[['Calendar_Week_Year','SAP_SKU','Weighted Sales Target Var', 'Timestamp']]
    aggregations = {'Weighted Sales Target Var':'sum'}
    dfsales = dfsales.groupby(['Calendar_Week_Year','SAP_SKU', 'Timestamp']).agg(aggregations).reset_index()
    dfsales['Calendar_Week_Year'] = dfsales['Calendar_Week_Year'].astype('str')
    df['Calendar_Week_Year'] = df['CalendarWeek'].astype('str')#+df['CalWeekNbr'].astype('str')
    dfsales['Timestamp'] = dfsales['Timestamp'].apply(lambda x:pd.to_datetime(x))
    del df['CalendarWeek']
    del df['CalWeekNbr']
    df1 = pd.merge(dfsales, df, on='Calendar_Week_Year', how='left')
    return predictor(df1,res,sku, sku_channel, lag_predict)


from flask import Flask, request, send_file, render_template

app = Flask(__name__, template_folder='./html')

@app.route('/')
def hello():
    return render_template('index_pred.html')

@app.route('/test', methods=['POST'])
def test_view():
    # TODO implement
    try:
        #return str(request.form.items())
        skunumber = eval(str(request.form.get("sku_number")))
        lag_predict = eval(str(request.form.get("lag_predict")))
        print(lag_predict)
        df = main(skunumber,lag_predict)
        df.to_csv("predictor"+str(skunumber)+".csv", index=False)
        #s3.Bucket('jbs-demand-forecasting').upload_file(Filename="predictor"+str(skunumber)+".csv", Key='outputs/'+"predictor"+str(skunumber)+".csv")
        outpath = os.path.join(str(os.getcwd()),"predictor"+str(skunumber)+".csv")
        return send_file(outpath, as_attachment=True)
        #return "please check output at this link."
    except Exception as e:
        raise
        print(e)
        return "wrong inputs given, please cross check."
app.run(host='0.0.0.0',port=3002)


