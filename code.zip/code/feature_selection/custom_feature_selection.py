from sklearn.base import MultiOutputMixin, BaseEstimator
from feature_selection.selection_methods import *
import pandas as pd


from sklearn.base import MultiOutputMixin, BaseEstimator


# class FeatureSelection(MultiOutputMixin, BaseEstimator):
#     def __init__(
#         self, selLagFeat: int, selNoLagFeat: int, vote: int, lagged_feature: list
#     ):
#         """
#         FeatureSelection class is used to select feature from the set feature
#         using different selection methods like correlation, Random Forest, OLS etc
#         and vote among them to select a set of features

#         Parameters
#         ---------------------------
#         selLagFeat: int
#             Number of lagged feature has to be selected

#         selNoLagFeat: int
#             Number of Non lagged feature has to be selected

#         vote : int
#             Threshold

#         lagged_feature : list
#             list of parent names of lagged columns in data

#         """

#         print("\n>>>>>>>FeatureSelection init() called.\n")

#         self.laggedCols = lagged_feature

#         self.selectedNoLagFeatureCorr = []
#         self.selectedNoLagFeatureSpearmanCorr = []
#         self.selectedNoLagFeatureOLS = []
#         self.selectedNoLagFeatureRF = []

#         self.selectedLaggedFeatureCorr = []
#         self.selectedLaggedFeatureSpearmanCorr = []
#         self.selectedLaggedFeatureOLS = []
#         self.selectedLaggedFeatureRF = []

#         self.selectedColumns = []
#         self.selectedLagColumns = []
#         self.selectedNoLagColumns = []

#         self.lag_columns = []
#         self.nolag_columns = []

#         self.selNoLagFeat = selNoLagFeat
#         self.vote = vote
#         self.selLagFeat = selLagFeat

#     def fit(self, X, y=None):
#         print("\n>>>>>>>FeatureSelection fit() called.\n")

#         y_ = pd.DataFrame({"target": y})
#         #         print("FeatureSelection--X:")
#         #         print(X)
#         #         print("\n\n")
#         #         print("FeatureSelection--Y:", y_)
#         #         print(y_)
#         #         print("\n\n")

#         # Filtering out Non lag columns
#         self.nolag_columns = list(
#             filter(lambda x: True if "_Lag_" not in x else False, X.columns)
#         )
#         print("************************************************************")
#         print("Feature Selection for No lagged variable", self.nolag_columns)
#         print("************************************************************")
#         self.selectedNoLagFeatureCorr = selectCorrelatedFeature(
#             X[self.nolag_columns], y_
#         )  ##Pearson
#         self.selectedNoLagFeatureSpearmanCorr = selectCorrelatedFeature(
#             X[self.nolag_columns], y_, method="spearman"
#         )  ##Spearman
#         self.selectedNoLagFeatureOLS = selectFeatureOLS(
#             X[self.nolag_columns], y_
#         )  ##OLS
#         self.selectedNoLagFeatureRF = feature_selection_random(
#             X[self.nolag_columns], y_, self.selNoLagFeat
#         )  ##Random Forest

#         print("************************************************************")
#         print("Feature Selection for Lagged variable")
#         print("************************************************************")
#         for lag_col in self.laggedCols:
#             print("Lagged Feature Selection for feature ", lag_col, " :")

#             # Filtering out lag columns by "_Lag_" key word
#             laggedFeature = list(
#                 filter(
#                     lambda x: True if x.startswith(lag_col + "_Lag_") else False,
#                     X.columns,
#                 )
#             )

#             print(laggedFeature, "\n")

#             LaggedFeatureCorr = selectCorrelatedFeature(
#                 X[laggedFeature], y_
#             )  ## Pearson
#             #             print(
#             #                 "Selected Lagged Feature considering Peason Correlation for ",
#             #                 lag_col, ## Parent Column name
#             #                 " :\n\n",
#             #                 LaggedFeatureCorr, ## Child column
#             #                 "\n\n",
#             #             )

#             LaggedFeatureSpearmanCorr = selectCorrelatedFeature(
#                 X[laggedFeature], y_, method="spearman"
#             )  ## Spearman
#             #             print(
#             #                 "Selected Lagged Feature considering Spearman Correlation for ",
#             #                 lag_col,
#             #                 " :\n\n",
#             #                 LaggedFeatureSpearmanCorr,
#             #                 "\n\n",
#             #             )

#             LaggedFeatureOLS = selectFeatureOLS(X[laggedFeature], y_)  ## OLS
#             #             print(
#             #                 "Selected Lagged Feature considering OLS Model for ",
#             #                 lag_col,
#             #                 " :\n\n",
#             #                 LaggedFeatureOLS,
#             #                 "\n\n",
#             #             )

#             LaggedFeatureRidge = feature_selection_random(  ## Random Forest
#                 X[laggedFeature], y_, self.selLagFeat
#             )
#             #             print(
#             #                 "Selected Lagged Feature considering Random Forest for ",
#             #                 lag_col,
#             #                 " :\n\n",
#             #                 LaggedFeatureRidge,
#             #                 "\n\n",
#             #             )

#             # Creating an empty list and appending the selected lagged feature of one parent feature and then selecting the best one
#             # based on Voting
#             selectCols = []
#             selectCols.append(LaggedFeatureCorr)
#             selectCols.append(LaggedFeatureSpearmanCorr)
#             selectCols.append(LaggedFeatureOLS)
#             selectCols.append(LaggedFeatureRidge)
#             selectedLaggedFeatureVote = select_columns(selectCols, self.vote)

#             print("\n")
#             print(
#                 "Selected Lagged Feature based on Voting for ",
#                 lag_col,
#                 " :\n",
#                 selectedLaggedFeatureVote,
#                 "\n\n",
#             )

#             self.selectedLaggedFeatureCorr += LaggedFeatureCorr
#             self.selectedLaggedFeatureSpearmanCorr += LaggedFeatureSpearmanCorr
#             self.selectedLaggedFeatureOLS += LaggedFeatureOLS
#             self.selectedLaggedFeatureRF += LaggedFeatureRidge

#         print(
#             "*************************************************************************************************"
#         )
#         print(
#             "\nTotal selected LaggedFeature from Pearson Correlation:\n",
#             self.selectedLaggedFeatureCorr,
#             "\n",
#         )
#         print(
#             "*************************************************************************************************"
#         )

#         print(
#             "*************************************************************************************************"
#         )
#         print(
#             "\n\nTotal selected LaggedFeature from Spearman Correlation:\n",
#             self.selectedLaggedFeatureSpearmanCorr,
#             "\n\n",
#         )
#         print(
#             "*************************************************************************************************"
#         )

#         print(
#             "*************************************************************************************************"
#         )
#         print(
#             "Total selected LaggedFeature from OLS Regression:\n",
#             self.selectedLaggedFeatureOLS,
#             "\n\n",
#         )
#         print(
#             "*************************************************************************************************"
#         )

#         print(
#             "*************************************************************************************************"
#         )
#         print(
#             "Total selected LaggedFeature from Random Forest:\n",
#             self.selectedLaggedFeatureRF,
#             "\n\n",
#         )

#         print(
#             "*************************************************************************************************"
#         )
#         print(
#             "\n\nselected NoLagFeature from Pearson Correlation:\n",
#             self.selectedNoLagFeatureCorr,
#             "\n\n",
#         )
#         print(
#             "*************************************************************************************************"
#         )

#         print(
#             "*************************************************************************************************"
#         )
#         print(
#             "\n\nselected NoLagFeature from Spearson Correlation:\n",
#             self.selectedNoLagFeatureSpearmanCorr,
#             "\n\n",
#         )
#         print(
#             "*************************************************************************************************"
#         )

#         print(
#             "*************************************************************************************************"
#         )
#         print(
#             "selected NoLagFeature from OLS Regression:\n",
#             self.selectedNoLagFeatureOLS,
#             "\n\n",
#         )
#         print(
#             "*************************************************************************************************"
#         )

#         print(
#             "*************************************************************************************************"
#         )
#         print(
#             "selected NoLagFeature from Random Forest:\n",
#             self.selectedNoLagFeatureRF,
#             "\n\n",
#         )
#         print(
#             "*************************************************************************************************"
#         )

#         return self

#     def transform(self, X, y=None):
#         print("\n>>>>>>>FeatureSelection transform() called.\n")

#         print(X.columns)
#         filterLagCol = []
#         filterLagCol.append(self.selectedLaggedFeatureCorr)
#         filterLagCol.append(self.selectedLaggedFeatureSpearmanCorr)
#         filterLagCol.append(self.selectedLaggedFeatureOLS)
#         filterLagCol.append(self.selectedLaggedFeatureRF)
#         self.selectedLagColumns = select_columns(filterLagCol, self.vote)

#         filterNoLagCol = []
#         filterNoLagCol.append(self.selectedNoLagFeatureCorr)
#         filterNoLagCol.append(self.selectedNoLagFeatureSpearmanCorr)
#         filterNoLagCol.append(self.selectedNoLagFeatureOLS)
#         filterNoLagCol.append(self.selectedNoLagFeatureRF)
#         self.selectedNoLagColumns = select_columns(filterNoLagCol, self.vote)

#         self.selectedColumns = self.selectedLagColumns + self.selectedNoLagColumns

#         print("selected feature :\n", self.selectedColumns)
#         if "const" in self.selectedColumns:
#             self.selectedColumns = list(set(self.selectedColumns))
#             self.selectedColumns.remove("const")

#         return X[self.selectedColumns]


from sklearn.base import MultiOutputMixin, BaseEstimator


class FeatureSelection(MultiOutputMixin, BaseEstimator):
    def __init__(
        self, selLagFeat: int, selNoLagFeat: int, vote: int, lagged_feature: list
    ):
        """
        FeatureSelection class is used to select feature from the set feature
        using different selection methods like correlation, Random Forest, OLS etc
        and vote among them to select a set of features

        Parameters
        ---------------------------
        selLagFeat: int
            Number of lagged feature has to be selected

        selNoLagFeat: int
            Number of Non lagged feature has to be selected

        vote : int
            Threshold

        lagged_feature : list
            list of parent names of lagged columns in data

        """

        print("\n>>>>>>>FeatureSelection init() called.\n")

        self.laggedCols = lagged_feature

        self.selectedNoLagFeatureCorr = []
        self.selectedNoLagFeatureSpearmanCorr = []
        self.selectedNoLagFeatureOLS = []
        self.selectedNoLagFeatureRF = []

        self.selectedLaggedFeatureCorr = []
        self.selectedLaggedFeatureSpearmanCorr = []
        self.selectedLaggedFeatureOLS = []
        self.selectedLaggedFeatureRF = []

        self.selectedColumns = []
        self.selectedLagColumns = []
        self.selectedNoLagColumns = []

        self.lag_columns = []
        self.nolag_columns = []

        self.selNoLagFeat = selNoLagFeat
        self.vote = vote
        self.selLagFeat = selLagFeat

    def fit(self, X, y=None):
        print("\n>>>>>>>FeatureSelection fit() called.\n")

        y_ = pd.DataFrame({"target": y})
        #         print("FeatureSelection--X:")
        #         print(X)
        #         print("\n\n")
        #         print("FeatureSelection--Y:", y_)
        #         print(y_)
        #         print("\n\n")

        # Filtering out Non lag columns
        self.nolag_columns = list(
            filter(lambda x: True if "_Lag_" not in x else False, X.columns)
        )
        print("************************************************************")
        print("Feature Selection for No lagged variable", self.nolag_columns)
        print("************************************************************")
        self.selectedNoLagFeatureCorr = selectCorrelatedFeature(
            X[self.nolag_columns], y_
        )  ##Pearson
        self.selectedNoLagFeatureSpearmanCorr = selectCorrelatedFeature(
            X[self.nolag_columns], y_, method="spearman"
        )  ##Spearman
        self.selectedNoLagFeatureOLS = selectFeatureOLS(
            X[self.nolag_columns], y_
        )  ##OLS
        self.selectedNoLagFeatureRF = feature_selection_random(
            X[self.nolag_columns], y_, self.selNoLagFeat
        )  ##Random Forest

        print("************************************************************")
        print("Feature Selection for Lagged variable")
        print("************************************************************")

        self.lag_columns = list(
            filter(lambda x: True if "_Lag_" in x else False, X.columns)
        )
        print(self.lag_columns, "\n")

        self.selectedLaggedFeatureCorr = selectCorrelatedFeature(
            X[self.lag_columns], y_
        )  ## Pearson
        self.selectedLaggedFeatureSpearmanCorr = selectCorrelatedFeature(
            X[self.lag_columns], y_, method="spearman"
        )  ## Spearman
        self.selectedLaggedFeatureOLS = selectFeatureOLS(
            X[self.lag_columns], y_
        )  ## OLS
        self.selectedLaggedFeatureRF = feature_selection_random(
            X[self.lag_columns], y_, self.selLagFeat
        )

        print(
            "*************************************************************************************************"
        )
        print(
            "\nTotal selected LaggedFeature from Pearson Correlation:\n",
            self.selectedLaggedFeatureCorr,
            "\n",
        )
        print(
            "*************************************************************************************************"
        )

        print(
            "*************************************************************************************************"
        )
        print(
            "\n\nTotal selected LaggedFeature from Spearman Correlation:\n",
            self.selectedLaggedFeatureSpearmanCorr,
            "\n\n",
        )
        print(
            "*************************************************************************************************"
        )

        print(
            "*************************************************************************************************"
        )
        print(
            "Total selected LaggedFeature from OLS Regression:\n",
            self.selectedLaggedFeatureOLS,
            "\n\n",
        )
        print(
            "*************************************************************************************************"
        )

        print(
            "*************************************************************************************************"
        )
        print(
            "Total selected LaggedFeature from Random Forest:\n",
            self.selectedLaggedFeatureRF,
            "\n\n",
        )

        print(
            "*************************************************************************************************"
        )
        print(
            "\n\nselected NoLagFeature from Pearson Correlation:\n",
            self.selectedNoLagFeatureCorr,
            "\n\n",
        )
        print(
            "*************************************************************************************************"
        )

        print(
            "*************************************************************************************************"
        )
        print(
            "\n\nselected NoLagFeature from Spearson Correlation:\n",
            self.selectedNoLagFeatureSpearmanCorr,
            "\n\n",
        )
        print(
            "*************************************************************************************************"
        )

        print(
            "*************************************************************************************************"
        )
        print(
            "selected NoLagFeature from OLS Regression:\n",
            self.selectedNoLagFeatureOLS,
            "\n\n",
        )
        print(
            "*************************************************************************************************"
        )

        print(
            "*************************************************************************************************"
        )
        print(
            "selected NoLagFeature from Random Forest:\n",
            self.selectedNoLagFeatureRF,
            "\n\n",
        )
        print(
            "*************************************************************************************************"
        )

        return self

    def transform(self, X, y=None):
        print("\n>>>>>>>FeatureSelection transform() called.\n")

        print(X.columns)
        filterLagCol = []
        filterLagCol.append(self.selectedLaggedFeatureCorr)
        filterLagCol.append(self.selectedLaggedFeatureSpearmanCorr)
        filterLagCol.append(self.selectedLaggedFeatureOLS)
        filterLagCol.append(self.selectedLaggedFeatureRF)
        self.selectedLagColumns = select_columns(filterLagCol, self.vote)

        filterNoLagCol = []
        filterNoLagCol.append(self.selectedNoLagFeatureCorr)
        filterNoLagCol.append(self.selectedNoLagFeatureSpearmanCorr)
        filterNoLagCol.append(self.selectedNoLagFeatureOLS)
        filterNoLagCol.append(self.selectedNoLagFeatureRF)
        self.selectedNoLagColumns = select_columns(filterNoLagCol, self.vote)

        self.selectedColumns = self.selectedLagColumns + self.selectedNoLagColumns

        if "const" in self.selectedColumns:
            self.selectedColumns = list(set(self.selectedColumns))
            self.selectedColumns.remove("const")

        print("selected feature :\n", self.selectedColumns)

        return X[self.selectedColumns]
