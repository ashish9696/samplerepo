import os
import joblib
import io
import flask
import pandas as pd
from flask import jsonify, request, send_file
import base64

# from pydantic import BaseModel
from os.path import join
from inference import inference

model_path = os.environ["MODEL_PATH"]


# The flask app for serving predictions
app = flask.Flask(__name__)


class ScoringService(object):
    model = None  # Where we keep the model when it's loaded

    @classmethod
    def get_model(cls):
        """Get the model object for this instance, loading it if it's not already loaded."""
        if cls.model is None:
            with open(os.path.join(model_path, "model.pkl"), "rb") as f:
                cls.model = joblib.load(f)
        return cls.model


@app.route("/ping", methods=["GET"])
def ping():
    """Determine if the container is working and healthy. In this sample container, we declare
    it healthy if we can load the model successfully."""
    health = (
        ScoringService.get_model() is not None
    )  # You can insert a health check here

    status = 200 if health else 404
    return flask.Response(response="\n", status=status, mimetype="application/json")

@app.route('/')
def form():
    return """
        <html>
            <body>
                <h1>Upload Prediction Input</h1>

                <form action="/invocations" method="post" enctype="multipart/form-data">
                    <input type="file" name="external_data" />
                    <input type="submit" />
                </form>
            </body>
        </html>
    """


@app.route("/invocations", methods=["POST"])
def transformation():
    """Do an inference on a single batch of data. In this sample server, we take data as CSV, convert
    it to a pandas data frame for internal use and then convert the predictions back to CSV (which really
    just means one prediction per line, since there's a single column.
    """
    data = None
    print(request)
    f = request.files['external_data']
    f.save(os.path.join(os.getcwd(), "external_data.csv"))
    data = pd.read_excel("external_data.csv")
    #data = request.get_json(force=True)
    #data = data["content"]
    #print(data)

    ####Decode the data from recieved from the API
    #data = base64.b64decode(data)

    ### Reading the datafile as Excel
    #try:
    #    data = pd.read_excel(data)
    #except:
    #    data = pd.read_csv(data)

    print("Invoked with {} records".format(data.shape[0]))

    model_config_path = "model_config_file"

    with open(os.path.join(model_path, "model.pkl"), "rb") as f:
        model = joblib.load(f)

    transformer = joblib.load(join(model_config_path, "tranform1_StdScaler"))
    column_sequence = joblib.load(join(model_config_path, "column_sequence"))
    # model = joblib.load(join(model_config_path, "model.pkl"))
    imputed_value = joblib.load(join(model_config_path, "imputed_value"))
    # data = pd.read_excel(data_file.file.read(), sheet_name=0, header=0)
    predicted_data = inference(model, transformer, column_sequence, imputed_value, data)
    #print(predicted_data)
    try:
        predicted_data["Date"] = predicted_data.index.date
    except:
        predicted_data["Date"] = predicted_data.index

    respData = predicted_data[["Date", "Prediction"]]
    respData.fillna(value="Prediction Not found", inplace=True)
    forecast = []

    for data in range(respData.shape[0]):
        r = dict(zip(respData.iloc[data, :].index, respData.iloc[data, :].values))
        forecast.append(r)
    forecast = pd.DataFrame(forecast)
    predicted_data.to_csv("pred.csv")
    outpath = os.path.join(str(os.getcwd()), "pred.csv")
    return send_file(outpath, as_attachment=True)
    print(forecast.head())
    response = {"result": "completed"}

    #return response
app.run(host='0.0.0.0',port=3002)