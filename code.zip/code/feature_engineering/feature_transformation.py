### StandardScaler and Normality test for feature
from numpy.random import seed
from numpy.random import randn

from scipy.stats import normaltest

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import StandardScaler


class CustomStandardScaler(BaseEstimator, TransformerMixin):
    def __init__(self, feature_name: str, alpha: float = 0.05):
        """
        CustomBoxCoxStd is class used to check if columns for following
        gussian distribution or not. Columns which does not follow gussian
        distribution will be tranformed using StandardScaler

        Parameter
        -------------------------------------
        feature_name: list[str]
            contains the list of column names in dataset

        alpha: float

            P-value threshold for the normality test

        """
        self.feature_name = feature_name
        self.skewedFeature = []
        self.alpha = alpha
        self.std = StandardScaler()
        print("n>>>>>>>CustomBoxCoxStd init() called for features.\n", feature_name)

    def fit(self, X, y=None):
        print("\n>>>>>>>CustomBoxCoxStd fit() called.\n", self.feature_name)
        # X_copy = X.copy

        for col in self.feature_name:
            data = X[col]

            # normality test
            stat, p = normaltest(data)
            print("Statistics=%.3f, p=%.3f" % (stat, p))

            # interpret
            if p > self.alpha:
                print(col, " col looks Gaussian (fail to reject H0)")
            else:
                print(col, " column does not look Gaussian (reject H0)")
                self.skewedFeature.append(col)
        self.std.fit(X[self.skewedFeature])
        return self

    def transform(self, X, y=None):
        print("\n>>>>>>>CustomBoxCoxStd transform() called.\n")
        X_ = X.copy()  # creating a copy to avoid changes to original dataset
        X_[self.skewedFeature] = self.std.transform(X[self.skewedFeature])
        print(X_.head(3))

        return X_

    def inverse_transform(self, X, y=None):
        print("\n>>>>>>>CustomBoxCoxStd inverse_ transform() called.\n")
        X_ = X.copy()  # creating a copy to avoid changes to original dataset
        X_[self.skewedFeature] = self.std.inverse_transform(X[self.skewedFeature])

        print(X_.head(3))

        return X_
