import sys
from os.path import join
import joblib

import numpy as np
import pandas as pd


###############################################################
from data_preprocessing.missing_value_imputation import imputeMissingValue
from utils.getParentCol import getParentCol
from utils.isSubsetList import isSubsetList
from utils.getListDiff import getListDiff
from utils.createLagData import createLagData

from utils.getLagInfo import getLagInfoFromCols, getMaxLag

###############################################################

# def inference(model,data,lag_order:dict,selected_features:list,feature_tranformer):
def inference(model, transformer, column_sequence, imputed_value, data):
    try:
        lag_order = getLagInfoFromCols(column_sequence)
        max_lag = getMaxLag(lag_order)
        data.set_index("Time Series", inplace=True)

        cols = list(data.columns)
        tol_cols = list(map(lambda x: x.strip(), cols))

        original_data = data.copy()
        data[tol_cols] = data[cols]

        if max_lag > data.shape[0]:
            print("FAILED:: Minimun ", max_lag, " Rows required")
            raise Exception("FAILED:: Minimun " + str(max_lag) + " Rows required")

        selected_features = column_sequence[:]

        ## extracting parent columns
        parent_col_name = getParentCol(selected_features)
        print("Parent col of selected fature: ", parent_col_name)

        print("Total Columns in  data :: ", tol_cols)

        ## checking if parent column for present in training data or not
        if not isSubsetList(parent_col_name, tol_cols):
            print("func:training: All select features not found in inference data")

            raise Exception(
                "func:training: All select features not found in inference data"
            )

        if (
            data[parent_col_name].select_dtypes(include=np.number).columns.tolist()
            != parent_col_name
        ):
            print(
                data[parent_col_name].select_dtypes(include=np.number).columns.tolist()
            )
            raise Exception("Columns are not in numerical form")

        STAGE = """
        # -------------------------------------------------------------------------
        # ------------------------------Data Cleaning------------------------------
        # -------------------------------------------------------------------------
        """
        print("func:Inference: \n", STAGE)

        ## Selecting only required columns for further processing
        data = data[parent_col_name]
        ## Imputing missing values

        print("****************Before Imputation****************")
        print("\n")
        print(data.isna().sum())

        data = imputeMissingValue(data, imputed_value)

        print("****************After Imputation****************")
        print("\n")
        print(data.isna().sum())

        ## creating lag data for selected features
        ignore_lag_col = getListDiff(parent_col_name, list(lag_order.keys()))

        print("ignore columns whose lag is not required", ignore_lag_col)

        print(data.info())

        ## create lag data for training
        lagged_df = createLagData(data, lag_order, ignore_lag_col)
        # print(lagged_df.head(3))

        lagged_df = lagged_df[selected_features]
        ## droping null values
        lagged_df.dropna(inplace=True)
        print(lagged_df.head(3).to_markdown(tablefmt="grid"))

        STAGE = """
        # -------------------------------------------------------------------------
        # -----------------------Feature Transformation----------------------------
        # -------------------------------------------------------------------------
        """
        print("func:Inference: \n", STAGE)

        selected_cols = selected_features[:]
        X = lagged_df[selected_cols]

        print("Selected Feature Cols for Train")
        print(X.columns)

        print(X.info())
        ## Applying StandardScalar Tranformation

        transformed_1_data = X[column_sequence].copy()

        transformed_1_data[column_sequence] = transformer.transform(transformed_1_data)

        STAGE = """
        # -------------------------------------------------------------------------
        # ------------------------------Model Prediction-----------------------------
        # -------------------------------------------------------------------------
        """
        print("func:Inference: \n", STAGE)

        prediction = model.predict(transformed_1_data)

        print(data.loc[transformed_1_data.index])

        original_data.loc[transformed_1_data.index, "Prediction"] = prediction
        # print(prediction)
        # original_data.to_excel("prediction.xlsx")
        return original_data
    except Exception as e:
        print("Error: ", e)
        return None


if __name__ == "__main__":
    file_path ="..\data\Price Forecast Dataset for Pricing Model V7.0.xlsx"
    config_file_path ="..\code\config"
    model_config_file ="..\code\model_config_file"

    transformer = joblib.load(join(model_config_file, "tranform1_StdScaler"))
    column_sequence = joblib.load(join(model_config_file, "column_sequence"))
    model = joblib.load(join(model_config_file, "model.pkl"))
    imputed_value = joblib.load(join(model_config_file, "imputed_value"))
    data = pd.read_excel(file_path, sheet_name=3, header=0)
    predicted_data = inference(model, transformer, column_sequence, imputed_value, data)
    predicted_data.to_csv("predicted3.csv")
    #print("::::::::: Predicted Data ::::::::::")
    #if type(predicted_data) != None:
        #print(predicted_data.to_markdown(tablefmt="grid"))
