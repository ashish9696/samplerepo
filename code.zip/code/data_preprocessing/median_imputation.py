from pandas import DataFrame

## Median Imputation
def median_imputation(df: DataFrame):
    """median_imputation function is used to impute the columns
    if there is any missing value in column

    Args:
        df (DataFrame): Dataframe for imputation

    Returns:
        [DataFrame]: Imputed DataFrame
    """
    df_fill = df.copy()
    for i in df_fill.columns:
        if df_fill[i].isna().any():
            print(
                "Median for Column {} is {}".format(
                    i, str(round(df_fill[i].median(), 2))
                )
            )
            df_fill[i].fillna(round(df_fill[i].median(), 2), inplace=True)
        else:
            df_fill
    return df_fill
