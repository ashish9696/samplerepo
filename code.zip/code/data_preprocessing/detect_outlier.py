from pandas import DataFrame
from sklearn.ensemble import IsolationForest
import pandas as pd

###Detect Outlier By Isolation Forest


def isolation_forest_outlier_detect(data: DataFrame, target: str, ignore_cols: list):
    """
    isolation_forest_outlier_treatment function is used to identify outlier and then remove those
    instance from the dataframe.

    Parameters:
    -------------------------------------
    data: DataFrame
        Contain the dataframe in which data is present

    target:Str
        Target column for the usecase

    ignore_cols: list
        cols to ignore for which outlier analysis need not be done

    Return
    ---------------------------------
    outliers_index : list
        index of the outlier records in the provided dataframe

    outlier_df: dataframe
        Dataframe consisting only the outlier records

    """
    df = data.copy()
    df.drop(ignore_cols, axis=1, inplace=True)

    # Spliting Independent and Dependent Variables
    X = df.drop(target, axis=1)
    y = df[[target]]

    # identify outliers in the the dataset
    iso = IsolationForest(contamination=0.1)
    yhat = iso.fit_predict(X)

    # Detecting the outlier record's index
    outliers_index = list(df[yhat == -1].index)
    print(
        "Total Number of outliers are : {} and indexes of those Outlier records are :{}".format(
            len(outliers_index), outliers_index
        )
    )

    # Printing the dataset having only outlier records
    outlier_df = data.loc[outliers_index, :]

    return outliers_index, outlier_df


### By IQR

# This function will take the original dataframe as Input and will produce the output dataframe having columns which have outliers
def detect_outlier_IQR(df: DataFrame, ignore_list: list):
    df_final = df.drop(ignore_list, axis=1)
    Q1 = df_final.quantile(0.25)
    Q3 = df_final.quantile(0.75)
    IQR = Q3 - Q1

    iqr_out = ((df_final < (Q1 - 1.5 * IQR)) | (df_final > (Q3 + 1.5 * IQR))).sum()
    iqr_out_df = pd.DataFrame(iqr_out)
    iqr_out_df.rename(columns={"index": "Variables", 0: "Count"}, inplace=True)

    outlier_df = iqr_out_df[iqr_out_df.Count >= 1]
    return outlier_df
