import pandas as pd
from os.path import exists


def load_excel_data(path: str, sheet_name: int = 0, header_row: int = 0):
    """
    load_excel_data function is used to load the excel data from
    excel data

    Parameter:
    ------------------------------------
    path:str
        path of the file from where file is located.

    sheet_name:int
        sheet number of excel file. default value is 0.

    header_row:int
        header's row number.
    """

    if not exists(path):
        print("func:load_excel_data: Specified path doesn't exsists at path", path)
        return
    else:
        data = pd.read_excel(
            path, sheet_name=sheet_name, header=header_row, parse_dates=True
        )
        return data
