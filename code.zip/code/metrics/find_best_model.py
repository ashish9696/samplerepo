import pandas as pd


def getBestModel(result: pd.DataFrame, metrices: dict) -> str:
    columns = list(metrices.keys())
    condition = list(metrices.values())

    result.sort_values(by=columns, ascending=condition, inplace=True)
    # print(result.to_markdown())
    best_model = result["Model"].iloc[0]
    print("\n")
    print(
        "###################Best Model based on {} is :{} ######################".format(
            metrices, best_model
        )
    )
    print("\n")
    return best_model
