try:
    from utils.getParentCol import getParentCol
except ImportError as e:
    from getParentCol import getParentCol


def getLagInfoFromCols(features: list) -> dict:
    """
    getLagInfoFromCols function is used get the lag detail
    from the column list provided

    Parameter
    ------------------------
        features :list
         Column names from which the lag deatil need to be extracted

    Returns:
        dict: key value pair containing the column name and corresponding lag
    """
    parent_col = getParentCol(features)

    cols = list(filter(lambda x: True if "_Lag_" in x else False, features))
    col_lag = {}

    for col in parent_col:
        sel_col = list(filter(lambda x: True if col in x else False, cols))
        lags = list(map(lambda x: int(x.split("_")[-1]), sel_col))
        col_lag[col] = lags

    col_lag = {k: v for k, v in col_lag.items() if len(v) != 0}

    # col_lag = list(filter(lambda x: False if len(x)==0 else True))
    print("Lag information for the Selected Feature :: ", col_lag)
    print("\n\n")
    return col_lag


# lags = list(map(lambda x: int(x.split("_")[-1]),col))

# print(max(lags))


def getMaxLag(lag_order: dict) -> int:
    max_lag = 0

    max_col_lag = 0
    lags = []
    for col in lag_order:

        max_col_lag = max(lag_order[col])

        print("Max lag for col :: ", col, " is :: ", max_col_lag)
        lags.append(max_col_lag)

    max_lag = max(lags)

    return max_lag
