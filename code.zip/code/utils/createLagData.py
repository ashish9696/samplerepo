from pandas import DataFrame


def createLagData(data: DataFrame, lagOrder: dict, ignoreCol: list = []):
    """
    createLagData function is used to create lag columns for columns
    defined in the lagorder dictionary.

    Parameters:
    -------------------------------------
    data: DataFrame
        Contain the dataframe in which data is present

    lagOrder: dict
        key value pair dictionary object containing the
        key as column name and value as list contain the range of lag

    ignoreCol: list
        list of column name which we need to ignore will creating lag
    """
    df = data.copy()
    for col in lagOrder:
        if ignoreCol == [] or col not in ignoreCol:
            if len(lagOrder[col]) == 2:
                min_lag = lagOrder[col][0]
                max_lag = lagOrder[col][1]
                for lag in range(min_lag, max_lag + 1):
                    df[col + "_Lag_" + str(lag)] = df[col].shift(lag)
            else:
                for lag in lagOrder[col]:
                    df[col + "_Lag_" + str(lag)] = df[col].shift(lag)

            df.drop(col, inplace=True, axis=1)

    return df
