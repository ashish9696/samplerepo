def getFilterCols(total_cols: list, ignoreCols: list = []):
    """
    getFilterCols function is used to filter list of columns
    from total_cols by ignoring cols provide in ignoreCols.

    Parameters
    --------------
    total_cols: list
        List of columns

    ignoreCols: list
        List of columns to be ignored
    """
    if ignoreCols == []:
        return total_cols

    filtered_cols = list(
        filter(lambda x: True if x not in ignoreCols else False, total_cols)
    )

    return filtered_cols
