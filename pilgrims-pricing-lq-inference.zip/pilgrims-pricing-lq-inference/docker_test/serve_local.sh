#!/bin/sh

image=$1

docker run -v $(pwd)/code/model_config_file:/opt/ml/model -p 8080:8080 --rm ${image} serve
