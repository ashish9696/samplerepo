#!/bin/sh

image=$1

docker run -v $(pwd)/data/input:/opt/ml/input/data/training -v $(pwd)/code/model_config_file:/opt/ml/model --rm ${image} train
