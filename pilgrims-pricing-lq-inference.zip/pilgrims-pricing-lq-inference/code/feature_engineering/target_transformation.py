### StandardScaler test for Target Variable
from numpy.random import seed
from numpy.random import randn
from scipy.stats import normaltest
from sklearn.preprocessing import StandardScaler
from sklearn.base import BaseEstimator, TransformerMixin


class TargetCustomStandardScaler(BaseEstimator, TransformerMixin):
    def __init__(self, feature_name: str, alpha: float = 0.05):
        """
        TargetCustomStandardScaler is class used to check if columns for following
        gussian distribution or not. Columns which does not follow gussian
        distribution will be tranformed using StandardScaler

        Parameter
        -------------------------------------
        feature_name: list[str]
            contains the list of column names in dataset

        alpha: float

            P-value threshold for the normality test

        """
        self.feature_name = feature_name
        self.isSkewed = None
        self.alpha = alpha
        self.std = StandardScaler()
        print("n>>>>>>>CustomBoxCoxStd init() called for features.\n", feature_name)

    def fit(self, X, y=None):
        print("\n>>>>>>>CustomBoxCoxStd fit() called.\n", self.feature_name)
        X_ = X.copy
        print(X_)

        # normality test
        stat, p = normaltest(X)
        print("Statistics=%.3f, p=%.3f" % (stat, p))

        # interpret
        if p > self.alpha:
            print(self.feature_name, " col looks Gaussian (fail to reject H0)")
            self.isSkewed = False

        else:
            print(self.feature_name, " Sample does not look Gaussian (reject H0)")
            self.isSkewed = True
            self.std.fit(X.values.reshape(-1, 1))

        return self

    def transform(self, X, y=None):
        print("\n>>>>>>>CustomBoxCoxStd transform() called.\n")
        X_ = X.copy()  # creating a copy to avoid changes to original dataset
        if self.isSkewed:
            X_ = self.std.transform(X_.values.reshape(-1, 1))

        print(X_)

        return X_

    def inverse_transform(self, X, y=None):
        print("\n>>>>>>>CustomBoxCoxStd inverse_ transform() called.\n")
        X_ = X.copy()  # creating a copy to avoid changes to original dataset
        if self.isSkewed:
            X_ = self.std.inverse_transform(X_.values.reshape(-1, 1))

        return X_
