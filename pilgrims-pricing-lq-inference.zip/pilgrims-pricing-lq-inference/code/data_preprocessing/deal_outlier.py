from pandas import DataFrame
import numpy as np
import pandas as pd

try:
    from data_preprocessing.median_imputation import median_imputation
except ImportError as e:
    from median_imputation import median_imputation
# Handle Outliers by Isolation Forest


def deal_outlier_iso(
    data: DataFrame, outlier_list: list, target: str, ignore_cols: list
):
    """
    Deal Outlier function is used to handle the outlier instances by replacing the outlier values with Median of
    respective columns

    Parameters:
    -------------------------------------
    data: DataFrame
        Contain the dataframe in which data is present

    outlier list: list
        A list having the index of outlier records in the dataframe

    target:str
        Target column for the usecase

    ignore_cols: list
        A list having the columns for which outlier replacement is not needed.


        Return
    ---------------------------------
    final_res: dataframe
        Dataframe consisting all the records with outliers replaced with Median
    """

    df_new = data.copy()
    # Dropping the columns for which outlier replacement is not needed.
    df_new.drop(ignore_cols + [target], axis=1, inplace=True)

    # Creating a seprate dataframe for all the ignored columns which will be used for joining the clean dataframe post outlier treatment.
    df_time = data[ignore_cols + [target]]

    # Imputing all the outlier records with Nan which will be replaced with Median value later on.
    df_new.loc[outlier_list, :] = np.nan

    print("Total Outlier records- {}".format(len(outlier_list)))
    print("Total Missing records- {}".format(df_new.isna().sum()[1]))
    print(
        "Total Outlier records should be equal to Total Missing records - {}".format(
            len(outlier_list) == df_new.isna().sum()[1]
        )
    )

    # Treatment: Median Imputation
    # median_imputation() is a custom function to impute missing values with median for each variable
    clean_df = median_imputation(df_new)

    # Merging with Time dataframe to include time series columns
    df_time["ID"] = range(len(data))
    clean_df["ID"] = range(len(data))

    final_res = pd.merge(clean_df, df_time, on="ID")
    final_res.drop("ID", axis=1, inplace=True)

    print("*************VALIDATION************")
    print(
        "Outlier records in the original dataframe before treatment :",
        data.loc[outlier_list, :],
    )
    print(
        "Outlier records in the original dataframe after treatment :",
        clean_df.loc[outlier_list, :],
    )

    return final_res


# Deal by IQR
# This function will remove all those outlier instance and return the clean dataset.


def deal_outlier_IQR(data: DataFrame, ignore_cols: list, target: str):
    """
    deal_outlier_IQR function is used to handle the outlier instances by replacing the outlier values with Median of
    respective columns. IQR technique has been used for this

    Parameters:
    -------------------------------------
    data: DataFrame
        Contain the dataframe in which data is present

    target:str
        Target column for the usecase.Usually a time series col



    Return
    ---------------------------------
    final_res: dataframe
        Dataframe consisting all the records with outliers replaced with Median
    """

    # Creating 2 different dataframe one for holding all the potential independent vars and another for holding ignore cols
    df_test = data.drop(ignore_cols + [target], axis=1)
    df_ignore = data[ignore_cols + [target]]

    # Finding IQR for each factor
    Q1 = df_test.quantile(0.25)
    Q3 = df_test.quantile(0.75)
    IQR = Q3 - Q1
    #     print("IQR for Each features :")
    #     print(IQR)

    # Finding outlier by using Q1+/-1.5IQR Method
    mask = (df_test < (Q1 - 1.5 * IQR)) | (df_test > (Q3 + 1.5 * IQR))

    # Replacing the oulier instances with Nan for each of the factor in the dataframe so that those instances can be imputed with Median
    df_test[mask] = np.nan

    print(
        "Total Missing Records in dataframe after imputing Outliers instances with Nan which shoule be same as the outlier reported:"
    )
    print(df_test.isna().sum()[df_test.isna().sum().values >= 1])
    # print("Total Outlier records should be equal to Total Missing records - {}".format(len(outlier_list) == df_new.isna().sum()[1]))

    # Doing Median imputation for all the factors for which Nan will be there(i.e Potential Outliers)
    final = median_imputation(df_test)

    # Creating a ID column which will be used for Joining the ignore col dataframe created above with the cleaned data
    df_ignore["ID"] = range(len(data))
    final["ID"] = range(len(data))

    # Joining of the 2 tables
    final_res = pd.merge(final, df_ignore, on="ID")
    final_res.drop("ID", axis=1, inplace=True)

    return final_res
