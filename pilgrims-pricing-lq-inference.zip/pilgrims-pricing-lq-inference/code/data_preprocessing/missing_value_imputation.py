import pandas as pd
from pandas import DataFrame
import numpy as np


def missing_val_imputation(data: DataFrame, ts_cols: str) -> (DataFrame, dict):
    """
    missing_val_imputation is function to impute the missing values with different techniques.
    It handles imputation seprately for Time Series factor and other available factors.

    Parameter
    --------------------------------
    data:DataFrame
        the primary dataframe in which missing values need to be checked and imputed
    ts_col:str
        Time Series column

    Return
    ---------------------------------
    test : DataFrame
        Clean dataframe without missing values
    imputed_value : dict
        key value pair containing the imputed value for each columns
    """

    test = data.copy()

    imputed_value = {}

    for ts_col in ts_cols:
      if test[ts_col].isna().sum():
            # Missing Value for time Series col
            missing_ts_index = test[test[ts_col].isna()][ts_col].index - 1
            print(missing_ts_index)
    
            # Value to replace
            val = pd.DatetimeIndex(
                test.loc[missing_ts_index, ts_col].values
            ) + pd.DateOffset(months=1)
            print(val[0])
    
            # replacement
            test[ts_col].fillna(val[0], inplace=True)
      else:
          test
    

    for i in test.columns:
        if i != ts_col and test[i].dtype != np.object:
            if test[i].isna().any():
                print("Imputing for Column {} with Mean {}".format(i, test[i].mean()))
                test[i].fillna(test[i].mean(), inplace=True)
                imputed_value[i] = test[i].mean()
            else:
                imputed_value[i] = test[i].mean()

    return test, imputed_value


def imputeMissingValue(data: DataFrame, imputed_value: dict) -> DataFrame:

    for col in data.columns:
        if data[col].isna().sum() != 0:
            print("Imputing for Column {} with Mean {}".format(col, imputed_value[col]))
            data[col].fillna(imputed_value[col], inplace=True)

    return data
