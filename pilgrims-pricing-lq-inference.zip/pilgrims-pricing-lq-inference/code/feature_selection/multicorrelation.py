from pandas import DataFrame
import pandas as pd
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tools.tools import add_constant


def highestCorrelatedFeat(
    data: DataFrame, top: int, feature: list, method: str = "pearson"
):
    """
    highestCorrelatedFeat function is used to calculate correlation among
    the selected feature and returns top n correlated features

    Parameters
    --------------
    data: DataFrame
        Dataframe contain the data
    top: int
        top n correlated feature
    feature: list
        Selected feature for which correlation has to be considered

    method: str
        method used to calculated the correlation

    Return
    --------------
    top_feature: DataFrame
        dataframe contain correlation value among the features

    """
    col1 = []
    col2 = []
    corr = []

    for feat1 in range(len(feature) - 1):
        correlation = data.corrwith(data[feature[feat1]], method=method)

        for feat2 in range(feat1 + 1, len(feature)):
            correlation_cof = correlation[feature[feat2]]
            col1.append(feature[feat1])
            col2.append(feature[feat2])
            corr.append(correlation_cof)

    feature_corr = pd.DataFrame(
        {"feature_1": col1, "feature_2": col2, "correlation": corr}
    )
    # print(feature_corr)

    if top == 0 or top > data.shape[0]:
        top_feature = feature_corr[
            (feature_corr["correlation"] >= 0.5) | (feature_corr["correlation"] <= -0.5)
        ]
        return top_feature
    else:
        top_feature = feature_corr[
            (feature_corr["correlation"] >= 0.5) | (feature_corr["correlation"] <= -0.5)
        ]
        top_feature = feature_corr.sort_values(by="correlation", ascending=False).iloc[
            :top, :
        ]
        return top_feature


def calc_vif(X: DataFrame):

    # Calculating VIF
    # X = add_constant(X)
    vif = pd.DataFrame()
    vif["variables"] = X.columns
    vif["VIF"] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]

    return vif


## Removing Multi Correlated Features
def remove_multi_correlation(X: DataFrame):

    X_ = X.copy()

    ##Creating a loop which will be keep on running until the VIF value against all the available factors drops down a certain
    # threshold value
    while calc_vif(X_)["VIF"].max() > 10:
        df = calc_vif(X_)
        var = str(df.loc[df["VIF"] == df["VIF"].max()]["variables"].iloc[0])
        print("Removing {} as VIF calculated to be {}".format(var, df["VIF"].max()))
        X_.drop(var, inplace=True, axis=1)

    df = calc_vif(X_)
    df.set_index("variables", inplace=True)
    print("\n Final re-presentation of VIF :")
    print(df.loc[X_.columns, :])
    # print(df[df['variables'].isin(X.columns)])
    return X_
