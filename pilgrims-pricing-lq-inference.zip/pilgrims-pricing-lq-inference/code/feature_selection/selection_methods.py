from collections import Counter
import numpy as np
import pandas as pd

import statsmodels.api as sm
from sklearn.feature_selection import RFE, SelectFromModel
from sklearn.ensemble import RandomForestRegressor


## Selecting Common feature according to votes
def select_columns(sel_col, k):
    flattened_list = [y for x in sel_col for y in x]
    merged_dic = Counter(flattened_list)

    selected_col = []
    for keys in merged_dic:
        if merged_dic[keys] >= k:
            selected_col.append(keys)

    return selected_col


## Peason Correlation Feature Selection
def selectCorrelatedFeature(X, y, method="pearson"):
    print("Feature Selection using ", method, " Correlation")
    correlation = X.corrwith(y["target"], method=method)
    # print(correlation)
    df = pd.DataFrame(correlation)
    df.reset_index(level=0, inplace=True)
    df.columns = ["Feature", "Correlation"]
    print(df)
    correlation = correlation[(correlation >= 0.5) | (correlation <= -0.5)]
    print("Selected Features using ", method, " Correlation")
    # print(correlation)
    print(df.loc[(df["Correlation"] >= 0.5) | (df["Correlation"] <= -0.5)])

    return list(correlation.index)


## RFE with different Estimator feature selection
def selectRFEFeature(X, y, estimator, selK):
    print("Feature Selection Using RFE\n\n")
    selector = RFE(estimator, n_features_to_select=selK, step=1)
    selector = selector.fit(X, y)
    # print(list(zip(X.columns,selector.support_)))

    filterCols = list(
        filter(
            lambda x: True if x[1] else False, list(zip(X.columns, selector.support_))
        )
    )
    selectedCols = list(map(lambda x: x[0], filterCols))

    return selectedCols


## OSL model to select feature based on pvalue
## OLS Feature Selection
def selectFeatureOLS(X, y):
    print("Feature Selection Using OLS Model\n\n")

    X2 = sm.add_constant(X)
    est = sm.OLS(y, X2)
    est2 = est.fit()
    print(est2.summary())
    selectedCols = list(est2.pvalues[est2.pvalues <= 0.05].sort_values().index)
    print("\n")
    print("Selected Features using OLS")
    df = pd.DataFrame(est2.pvalues)  # Converting p values to dataframe
    df.reset_index(level=0, inplace=True)
    df.columns = ["Feature", "Pvalue"]
    df = df.round(3)
    print(df.loc[df["Pvalue"] <= 0.05])  # Printing  Selected Result
    # print(selectedCols)
    return selectedCols


## Random Forest to select feature based on feature importance
def feature_selection_random(X, Y, k, n_estimators=700):
    trainedforest = RandomForestRegressor(n_estimators).fit(X, Y)
    importances = trainedforest.feature_importances_
    _ = np.std(
        [tree.feature_importances_ for tree in trainedforest.estimators_], axis=0
    )
    indices = np.argsort(importances)[::-1]
    # Print the feature ranking
    print("Feature Importance :")

    list_randomforest_feature = list()
    dict_diff = dict()
    for f in range(X.shape[1]):
        # print(
        # "%d. %s (%f)" % (f + 1, X.columns[indices[f]], importances[indices[f]]),
        # end=" ",
        # )
        dict_diff[X.columns[indices[f]]] = importances[indices[f]]
        if f + 1 <= k:
            list_randomforest_feature.append(X.columns[indices[f]])
    df = pd.DataFrame.from_dict(dict_diff, orient="index")
    df.reset_index(level=0, inplace=True)
    df.columns = ["Feature", "Feature_Importance"]
    print(df)
    print("\n")
    print("Selected Features using Random Forest")
    # print(list_randomforest_feature)
    print(df.head(k))

    return list_randomforest_feature
