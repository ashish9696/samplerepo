#############################################################################
###################### FEATURE SELECTION PIPELINE ###########################
#############################################################################

import sys
from os.path import join
import json

from pandas import DataFrame
import pandas as pd

from sklearn.preprocessing import StandardScaler, MinMaxScaler

from data_loading.load_data import load_excel_data

from data_preprocessing.deal_outlier import deal_outlier_IQR
from data_preprocessing.missing_value_imputation import missing_val_imputation

from feature_selection.multicorrelation import remove_multi_correlation
from feature_selection.custom_feature_selection import FeatureSelection


from utils.isSubsetList import isSubsetList
from utils.createLagData import createLagData
from utils.getFilterCols import getFilterCols


file_path ="..\data\Price Forecast Dataset for Pricing Model V7.0.xlsx"
config_file_path ="..\code\config"
model_config_file ="..\code\model_config_file"


STAGE = """
# -------------------------------------------------------------------------
# ------------------------------Data Loading-------------------------------
# -------------------------------------------------------------------------
"""
print("func:feature_selection:\n", STAGE)

df = load_excel_data(file_path, sheet_name=3, header_row=0)

if not isinstance(df, DataFrame):
    print("func: feature_selection: No data found at path - ", file_path)
    sys.exit(0)

print(df.info())

STAGE = """
# -------------------------------------------------------------------------
# ------------------------------Reading CONFIG JSON's----------------------
# -------------------------------------------------------------------------
"""
print("func:feature_selection:\n", STAGE)

## read the columns_specification json file
with open(join(config_file_path, "columns_specification.json"), "r") as file:
    config = json.loads(file.read())

drop_cols = config.get("drop_column", "")
ts_cols = config.get("time_series_cols", "")
target = config.get("target", "")

# print("Target : ",target)
# print("time series cols : ",ts_cols)
# print("Drop columns : ",drop_cols)

if (
    not isinstance(drop_cols, list)
    or not isinstance(ts_cols, list)
    or not isinstance(target, str)
    or target == ""
):
    print("func:feature_selection: Error in config JSON")
    sys.exit(0)

print("Target : ", target)
print("time series cols : ", ts_cols)
print("Drop columns : ", drop_cols)

## read the lag Order json file

with open(join(config_file_path, "lagOrder.json"), "r") as file:
    lag_order = json.loads(file.read())

lag_cols = list(lag_order.keys())
tol_cols = list(df.columns)


check_lag_cols = isSubsetList(lag_cols, tol_cols)
# print(check_lag_cols,type(check_lag_cols))

if not isinstance(check_lag_cols, bool) or check_lag_cols == False:
    print(
        "func:feature_selection: Error in lagOrder json or specified columns are not in data"
    )
    sys.exit(0)

print(lag_order)

## read the parameter json file

with open(join(config_file_path, "parameter.json"), "r") as file:
    para = json.loads(file.read())

transformation_para = para["transformation"]
feature_selection_para = para["feature_selection"]

STAGE = """
# -------------------------------------------------------------------------
# ------------------------------Cleaning data------------------------------
# -------------------------------------------------------------------------
"""
print("func:feature_selection: \n", STAGE)

## Removing columns
if isSubsetList(drop_cols, tol_cols):
    df.drop(columns=drop_cols, axis=1, inplace=True)

## Imputing missing value if found
df, _ = missing_val_imputation(df, ts_cols)

# ## Removing Null values
# df.dropna(inplace=True)

## detecting outliers and treating them
# outlier_index,outlier_data = isolation_forest_outlier_detect(data=df,target=target,ignore_cols = ts_cols)

df = deal_outlier_IQR(data=df, ignore_cols=ts_cols, target=target)

## Creating lagged data

lagged_df = createLagData(df, lag_order)
# print(lagged_df.info())

## Dropping the null value's which was created due to lag from the data

lagged_df.dropna(inplace=True)
# print(lagged_df.info())

STAGE = """
# -------------------------------------------------------------------------
# ------------------------------Feature Engineering------------------------
# -------------------------------------------------------------------------
"""
print("func:feature_selection: \n", STAGE)

ignore_cols = ts_cols + [target]
tol_cols = list(lagged_df.columns)

selected_cols = getFilterCols(tol_cols, ignoreCols=ignore_cols)

X, y = lagged_df[selected_cols], lagged_df[target]

## Applying StandardScalar Tranformation
transformed_1_data = X.copy()


tranform1_StdScaler = StandardScaler()

tranform1_StdScaler.fit(X)

transformed_1_data[X.columns] = tranform1_StdScaler.transform(X)


STAGE = """
# -------------------------------------------------------------------------
# ------------------------------Feature Selection--------------------------
# -------------------------------------------------------------------------
"""
print("func:feature_selection: \n", STAGE)

feature_selection = FeatureSelection(
    selLagFeat=feature_selection_para["num_Lag_sel_feat"],
    selNoLagFeat=feature_selection_para["num_NoLag_sel_feat"],
    vote=feature_selection_para["vote"],
    lagged_feature=lag_cols,
)

feature_selection.fit(transformed_1_data, y)

selectedFeature_X = feature_selection.transform(transformed_1_data)

## Removing Multi Correlated Features

selectedFeature_X = remove_multi_correlation(selectedFeature_X)

## Writing Select Columns to XLSX file

selectedFeatureDict = {}
for k in lagged_df.columns:
    if k in list(selectedFeature_X.columns):
        selectedFeatureDict[k] = True
    else:
        selectedFeatureDict[k] = False

print("Factors in selectedFeature_X")
print("\n", selectedFeature_X.columns)
print("\n")
print("Factors in lagged_df")
print("\n", lagged_df.columns)

selFeatureDf = pd.DataFrame(
    {
        "Feature Name": list(selectedFeatureDict.keys()),
        "Required": list(selectedFeatureDict.values()),
    }
)

selFeatureDf.to_excel(join(model_config_file, "Feature Selected.xlsx"), index=False)
print(selFeatureDf.to_markdown(tablefmt="grid"))
# s = selFeatureDf.to_markdown()
# type(s)
# with open("README.md", "w") as f:
#     f.write("## Feature Selected for training" + "\n" + s)
