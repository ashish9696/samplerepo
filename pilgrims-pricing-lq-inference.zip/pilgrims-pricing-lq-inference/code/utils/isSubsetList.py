def isSubsetList(subset: list, parent: list):
    """
    isSubsetList is function to whether all element of subset list
    exsist in parent list or not

    Parameter
    --------------------------------
    subset:list
        sublist of list object
    parent:list
        parent list object

    Return
    ---------------------------------
    result : bool
        true if all the subset list element are present in
        parent list
    """
    if not isinstance(subset, list) or not isinstance(parent, list):
        print("func:isSubsetList: Parameter should be list type")
        return

    present = []
    absent = []
    for i in subset:
        if i in parent:
            present.append(i)
        else:
            absent.append(i)

    if len(absent) == 0:
        res = True
        print("All Columns Present in Parent DataFrame")
    else:
        res = False
        print("Columns absent in Parent DataFrame are :", absent)

    return res


# def isSubsetList(subset:list,parent:list):
#     '''
#     isSubsetList is function to whether all element of subset list
#     exsist in parent list or not

#     Parameter
#     --------------------------------
#     subset:list
#         sublist of list object
#     parent:list
#         parent list object

#     Return
#     ---------------------------------
#     result : bool
#         true if all the subset list element are present in
#         parent list
#     '''
#     if not isinstance(subset,list) or not isinstance(parent,list):
#         print("func:isSubsetList: Parameter should be list type")
#         return

#     # print(parent,subset)
#     # print([e in parent for e in subset])
#     result = all(e in parent for e in subset)
#     return result
