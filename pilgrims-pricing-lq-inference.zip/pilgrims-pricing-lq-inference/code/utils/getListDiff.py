def getListDiff(subset: list, parent: list):
    """
    getListDiff function is used to get element which
    are not present in subset.

    Parameters
    --------------------
    subset:list
        list of elements in subset
    parent: list
        list element in parent

    Return
    --------------------
    diff: list
        list of element not present in subset
    """

    diff = []
    for e in parent:
        if e not in subset:
            diff.append(e)

    return diff
