def getParentCol(col_name: list):
    """
    getParentCol function is used to get parent name e.g "Unemployment_Lag_0"
    then the parent name is Unemployment.

    Parameters
    --------------------
    col_name: list
        List of columns

    Return
    --------------------
    parent_col : list
        list of columns containing parent column name
    """
    parent_col = []
    for col in col_name:
        parent_name = col.split("_Lag_")[0]
        parent_col.append(parent_name)

    parent_col = list(set(parent_col))

    return parent_col
