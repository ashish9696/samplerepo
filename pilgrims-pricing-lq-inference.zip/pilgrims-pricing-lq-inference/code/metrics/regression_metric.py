from sklearn import metrics
import math
import numpy as np

import pandas as pd


def RMSLE(predict, target):
    total = lagged_data.columns
    for k in range(len(predict)):
        LPred = np.log1p(predict[k] + 1)
        LTarg = np.log1p(target[k] + 1)
        if not (math.isnan(LPred)) and not (math.isnan(LTarg)):
            total = total + ((LPred - LTarg) ** 2)

    total = total / len(predict)
    return np.sqrt(total)


def regression_matrices(X, y, y_pred):
    mat_dict = {}
    mat_dict["MAE"] = metrics.mean_absolute_error(y, y_pred)
    mat_dict["MSE"] = metrics.mean_squared_error(y, y_pred)
    mat_dict["RMSE"] = np.sqrt(((y_pred - y) ** 2).mean())
    mat_dict["MAPE"] = (abs((y - y_pred) / y).mean()) * 100
    mat_dict["R2"] = metrics.r2_score(y, y_pred)
    k = len(X.columns)
    r2 = metrics.r2_score(y, y_pred)
    n = len(y_pred)
    # mat_dict["Adj R2"] = 1 - ((1 - r2) * ((n - 1) / (n - (k + 1))))
    # mat_dict['RMSLE'] = RMSLE(y_pred,y)
    res = pd.DataFrame.from_dict(mat_dict.items()).transpose()
    res.columns = res.iloc[0]
    res.drop(res.index[0], inplace=True)
    return res
