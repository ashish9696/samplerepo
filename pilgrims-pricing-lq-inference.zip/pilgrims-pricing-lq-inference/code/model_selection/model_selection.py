import numpy as np
import pandas as pd

from sklearn import linear_model
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
from xgboost import XGBRegressor
from sklearn.svm import SVR
from metrics.regression_metric import regression_matrices


# Ridge Regression Sample function if anything you want to change please let me know


def tune_hyperpatameter(Model_Name, params_list, X, y, test_size):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42
    )

    if Model_Name == "RIDGE REGRESSION":
        Model_obj = linear_model.Ridge()

        Best_Estimator = (
            GridSearchCV(Model_obj, param_grid=params_list, cv=4, n_jobs=-1)
            .fit(X, y)
            .best_estimator_
        )
        y_hat = Best_Estimator.predict(X_test)
        res = regression_matrices(X_test, y_test, y_hat)

        res["Model"] = Model_Name

    elif Model_Name == "RANDOM FOREST":

        Model_obj = RandomForestRegressor(random_state=123456)

        Best_Estimator = (
            GridSearchCV(Model_obj, param_grid=params_list, cv=4, n_jobs=-1)
            .fit(X, y)
            .best_estimator_
        )

        y_hat = Best_Estimator.predict(X_test)
        res = regression_matrices(X_test, y_test, y_hat)

        res["Model"] = Model_Name

    elif Model_Name == "XGBOOST":
        Model_obj = XGBRegressor(objective="reg:squarederror")

        Best_Estimator = (
            GridSearchCV(
                estimator=Model_obj, param_grid=params_list, n_jobs=-1, iid=False, cv=4,
            )
            .fit(X, y)
            .best_estimator_
        )
        y_hat = Best_Estimator.predict(X_test)
        res = regression_matrices(X_test, y_test, y_hat)

        res["Model"] = Model_Name

    elif Model_Name == "ELASTIC NET":
        Model_obj = linear_model.ElasticNet()

        Best_Estimator = (
            GridSearchCV(Model_obj, param_grid=params_list, cv=4, n_jobs=-1)
            .fit(X, y)
            .best_estimator_
        )
        y_hat = Best_Estimator.predict(X_test)
        res = regression_matrices(X_test, y_test, y_hat)
        res["Model"] = Model_Name

    elif Model_Name == "SVR":

        Model_obj = SVR()

        Best_Estimator = (
            GridSearchCV(Model_obj, param_grid=params_list, cv=4, n_jobs=-1)
            .fit(X, y)
            .best_estimator_
        )

        y_hat = Best_Estimator.predict(X_test)
        res = regression_matrices(X_test, y_test, y_hat)
        res["Model"] = Model_Name

    return Best_Estimator, res
