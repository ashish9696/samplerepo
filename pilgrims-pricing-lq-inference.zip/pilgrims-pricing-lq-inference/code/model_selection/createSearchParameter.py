import numpy as np


def randomForestSearchParameters():
    """
    RandomForestSearchParameters function is used to create combination
    all possible hyperparameters for Random-Forest Model
    """
    # Number of trees in random forest
    n_estimators = [int(x) for x in np.linspace(start=2, stop=60, num=5)]
    # Number of features to consider at every split
    max_features = ["auto", "sqrt"]
    # Maximum number of levels in tree
    max_depth = [int(x) for x in np.linspace(10, 150, num=5)]
    max_depth.append(None)
    # Minimum number of samples required to split a node
    min_samples_split = [2, 5, 10]
    # Minimum number of samples required at each leaf node
    min_samples_leaf = [1, 2]
    # Method of selecting samples for training each tree
    bootstrap = [True, False]
    criterion = ["mae"]
    # Create the random grid
    random_grid = {
        "n_estimators": n_estimators,
        "criterion": criterion,
        "max_features": max_features,
        "max_depth": max_depth,
        "min_samples_split": min_samples_split,
        "min_samples_leaf": min_samples_leaf,
        "bootstrap": bootstrap,
    }
    print(
        "func:createSearchParameter: Search Parameter for RandomForest,\n", random_grid
    )
    return random_grid


def XGBoostSearchParameters():
    """
    XGBoostSearchParameters function is used to create combination
    all possible hyperparameters for XGBoost Model
    """

    xgb_grid = {
        "max_depth": range(1, 4, 2),
        "min_child_weight": range(1, 6, 1),
        "subsample": [i / 10.0 for i in range(6, 10)],
        "reg_alpha": [0.01, 0.05],
        "gamma": [i / 10.0 for i in range(0, 10)],
        "learning_rate": [0.1],
        "n_estimators": [50],
        "nthread": [4],
        "scale_pos_weight": [1],
        "seed": [27],
    }

    print("func:createSearchParameter: Search Parameter for XGBoost,\n", xgb_grid)
    return xgb_grid


def elasticNetSearchParameter() -> dict:
    """
    elasticNetSearchParameter function is used to create combination
    all possible hyperparameters for ElasticNet Model
    """

    alpha = [0, 1, 2, 3, 0.5]  ##Constant that multiplies the penalty terms.
    l1_ratio = [
        0,
        0.1,
        0.2,
        0.3,
        0.4,
        0.5,
        0.6,
        0.7,
        0.8,
        0.9,
        1,
    ]  ## The ElasticNet mixing parameter, with 0 <= l1_ratio <= 1.
    positive = [True, False]  ## Forces the coefficients to be positive.
    selection = ["cyclic", "random"]

    elastic_grid = {
        "alpha": alpha,
        "l1_ratio": l1_ratio,
        "positive": positive,
        "selection": selection,
    }

    return elastic_grid


def SVRSearchParameters():
    """
    SVRSearchParameters function is used to create combination
    all possible hyperparameters for SVR Model
    """

    SVR_grid = {
        "C": [0.1, 1, 10, 100, 1000],
        "gamma": [1, 0.1, 0.01, 0.001, 0.0001],
        "kernel": ["rbf"],
    }

    print("func:createSearchParameter: Search Parameter for SVR,\n", SVR_grid)
    return SVR_grid
