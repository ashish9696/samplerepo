#############################################################################
###################### MODEL TRAIN PIPELINE #################################
#############################################################################

from os.path import exists, join
import joblib
import sys
import json

import pandas as pd


from data_loading.load_data import load_excel_data

from data_preprocessing.deal_outlier import deal_outlier_IQR
from data_preprocessing.missing_value_imputation import missing_val_imputation

from sklearn.preprocessing import StandardScaler, MinMaxScaler


from model_selection.model_selection import tune_hyperpatameter
from model_selection.createSearchParameter import (
    randomForestSearchParameters,
    elasticNetSearchParameter,
    randomForestSearchParameters,
    XGBoostSearchParameters,
    SVRSearchParameters,
)

from metrics.find_best_model import getBestModel


from utils.getParentCol import getParentCol
from utils.isSubsetList import isSubsetList
from utils.getListDiff import getListDiff
from utils.createLagData import createLagData
from utils.getFilterCols import getFilterCols


def model_train(
    data: pd.DataFrame,
    parameter: dict,
    lag_order: dict,
    model_config_path: str,
    drop_cols: list,
    ts_cols: list,
    target: str,
    model_list: list,
    metrics: dict,
    selectedFeature: list,
):
    transformation_para = parameter["transformation"]
    feature_selection_para = parameter["feature_selection"]

    stage = """
    # -------------------------------------------------------------------------
    # ------------------------------Data Loading-------------------------------
    # -------------------------------------------------------------------------
    """
    print("func:training: \n", stage)

    ## loading Orignal data on which the model will be trained
    tol_cols = list(data.columns)
    print("Total Columns in the provided datast", tol_cols)

    ## Removing irrelevant columns which should not be considered for further analysis
    if isSubsetList(drop_cols, tol_cols):
        data.drop(columns=drop_cols, axis=1, inplace=True)

    print("selected feature : ", selectedFeature)
    ## extracting parent columns from lag columns from feature selected xlsx
    parent_col_name = getParentCol(selectedFeature)
    print("Parent col of selected fature: ", parent_col_name)

    ## The parent for all the lagged/non-lag variables
    ## should be present in the dataset the customer has provided to do the training.
    if not isSubsetList(parent_col_name, tol_cols):
        print("func:training: All select features not found in training data")
        sys.exit(0)

    ## Deselecting all those variables for which lag variables are not neeeded
    ## lag_order.keys() would have parent names for all the lagged variables
    ## parent_col_name  would have all the parent columns which the user has provided for training.
    ## ignore_lag_col will have all those variables for which lag variables are not neeeded
    ignore_lag_col = getListDiff(parent_col_name, list(lag_order.keys()))

    print("ignore columns whose lag is not required", ignore_lag_col)
    stage = """
    # -------------------------------------------------------------------------
    # ------------------------------Data Cleaning------------------------------
    # -------------------------------------------------------------------------
    """
    print("func:training: \n", stage)

    print(data.info())

    ## Imputing missing values on the entire dataset if found
    print(
        "#######################Imputation of Missing Value Starts#########################"
    )
    data, imputed_value = missing_val_imputation(data, ts_cols)

    ## Dumping the imputed values as an object as it will be used while doing the inference.
    joblib.dump(imputed_value, join(model_config_path, "imputed_value"))

    ## detecting outliers and treating them
    print("###############Dealing with the Outliers starts####################")
    data = deal_outlier_IQR(data=data, ignore_cols=ts_cols, target=target)

    ## create lag data for training
    ## ignore_lag_col : will have all the features for which lag variables will not be created
    print("###############Creation of the lagged variables starts###################")
    lagged_df = createLagData(data, lag_order, ignore_lag_col)

    ## droping null values
    lagged_df.dropna(inplace=True)
    print(lagged_df.head(3).to_markdown(tablefmt="grid"))

    stage = """
    # -------------------------------------------------------------------------
    # ------------------------------Feature Transformation---------------------
    # -------------------------------------------------------------------------
    """
    print("func:training: \n", stage)

    selected_cols = selectedFeature[:]

    ### Here selecting only those columns which were selected in the feature selection steps
    X, y = lagged_df[selected_cols], lagged_df[target]
    print("Selected Feature Cols for Train")
    print(X.columns)

    ## Applying StandardScalar Tranformation

    transformed_1_data = X.copy()

    tranform1_StdScaler = StandardScaler()

    tranform1_StdScaler.fit(X)

    transformed_1_data[X.columns] = tranform1_StdScaler.transform(X)

    ### creating a list of selected independent attributes or selected factors which are considered for
    ### Model training and dumping as an object which will be used while doing the inference.
    column_sequence = list(X.columns)
    joblib.dump(column_sequence, join(model_config_path, "column_sequence"))

    ### Dumping the standard scaler object which will be used while doing the inference
    joblib.dump(tranform1_StdScaler, join(model_config_path, "tranform1_StdScaler"))

    stage = """
    # -------------------------------------------------------------------------
    # ------------------------------Model Building-----------------------------
    # -------------------------------------------------------------------------
    """
    print("func:training:\n", stage)

    compare_list = []
    best_model = {}

    if "RIDGE REGRESSION" in model_list:

        print("###############MODEL 1 : RIDGE REGRESSION #################")
        ridge_params = {"alpha": [0.01, 0.02, 0.1, 0.2, 0.3, 0.4, 0.5, 1]}

        ridge_best_model, ridge_result = tune_hyperpatameter(
            Model_Name="RIDGE REGRESSION",
            params_list=ridge_params,
            X=transformed_1_data,
            y=y,
            test_size=0.3,
        )

        print(ridge_best_model.get_params())
        print(ridge_result.to_markdown(tablefmt="grid"))
        compare_list.append(ridge_result)
        best_model["RIDGE REGRESSION"] = ridge_best_model

    if "ELASTIC NET" in model_list:

        #####
        print("###############MODEL 2 : ELASTIC NET REGRESSION#################")
        elastic_params = elasticNetSearchParameter()

        elastic_best_model, elastic_result = tune_hyperpatameter(
            Model_Name="ELASTIC NET",
            params_list=elastic_params,
            X=transformed_1_data,
            y=y,
            test_size=0.3,
        )

        print(elastic_best_model.get_params())
        print(elastic_result.to_markdown(tablefmt="grid"))

        compare_list.append(elastic_result)
        best_model["ELASTIC NET"] = elastic_best_model

    if "XGBOOST" in model_list:

        print("###############MODEL 3 : XGBoost REGRESSION#################")
        xgb_params = XGBoostSearchParameters()
        # xgb_params = {
        #     "max_depth": [3],
        #     "min_child_weight": [5],
        #     "subsample": [0.7],
        #     "reg_alpha": [0.05],
        #     "gamma": [0.0],
        #     "learning_rate": [0.1],
        #     "n_estimators": [50],
        #     "nthread": [4],
        #     "scale_pos_weight": [1],
        #     "seed": [27],
        # }

        XGB_best_model, XGB_result = tune_hyperpatameter(
            Model_Name="XGBOOST",
            params_list=xgb_params,
            X=transformed_1_data,
            y=y,
            test_size=0.3,
        )

        print(XGB_best_model.get_params())
        print(XGB_result.to_markdown(tablefmt="grid"))
        compare_list.append(XGB_result)
        best_model["XGBOOST"] = XGB_best_model

    if "RANDOM FOREST" in model_list:

        print("###############MODEL 4 : RandomForest Regression#################")
        rf_params = randomForestSearchParameters()

        rf_best_model, rf_result = tune_hyperpatameter(
            Model_Name="RANDOM FOREST",
            params_list=rf_params,
            X=transformed_1_data,
            y=y,
            test_size=0.3,
        )

        print(rf_best_model.get_params())
        print(rf_result.to_markdown(tablefmt="grid"))
        compare_list.append(rf_result)
        best_model["RANDOM FOREST"] = rf_best_model

    if "SVR" in model_list:

        print("###############MODEL 5 : SVR #################")
        svr_params = SVRSearchParameters()

        svr_best_model, svr_result = tune_hyperpatameter(
            Model_Name="SVR",
            params_list=svr_params,
            X=transformed_1_data,
            y=y,
            test_size=0.3,
        )

        print(svr_best_model.get_params())
        print(svr_result.to_markdown(tablefmt="grid"))
        compare_list.append(svr_result)
        best_model["SVR"] = svr_best_model

    if len(compare_list) != 0:
        result = pd.concat(compare_list, axis=0)
        print(result.to_markdown(tablefmt="grid"))

        model_name = getBestModel(result, metrics)
        joblib.dump(best_model[model_name], join(model_config_path, "model.pkl"))

        return result

    else:
        print("No Match model found for training")
        sys.exit(1)


if __name__ == "__main__":

    file_path ="..\data\Price Forecast Dataset for Pricing Model V7.0.xlsx"
    config_file_path ="..\code\config"
    model_config_path ="..\code\model_config_file"


    stage = """
    # -------------------------------------------------------------------------
    # ------------------------------Reading the Config JSON's------------------
    # -------------------------------------------------------------------------
    """
    print("func:training: \n", stage)

    ## reading required Configuration file
    with open(join(config_file_path, "parameter.json")) as file:
        para = json.loads(file.read())

    with open(join(config_file_path, "lagOrder.json")) as file:
        lag_order = json.loads(file.read())

    ## read the columns_specification json file
    with open(join(config_file_path, "columns_specification.json"), "r") as file:
        config = json.loads(file.read())

    drop_cols = config.get("drop_column", "")
    ts_cols = config.get("time_series_cols", "")
    target = config.get("target", "")

    if (
        not isinstance(drop_cols, list)
        or not isinstance(ts_cols, list)
        or not isinstance(target, str)
        or target == ""
    ):
        print("func:feature_selection: Error in config JSON")
        sys.exit(0)

    print("Target : ", target)
    print("time series cols : ", ts_cols)
    print("Drop columns : ", drop_cols)

    ## loading selected feature xlxs
    selFeatureDf = load_excel_data(join(model_config_path, "Feature Selected.xlsx"))

    ## extract feature column which are marked as True or needs to be selected
    selectedFeature = list(
        selFeatureDf[selFeatureDf["Required"] == True]["Feature Name"].values
    )

    ## loading Orignal data
    df = load_excel_data(file_path, sheet_name=3, header_row=0)

    ##define model list and metrics for selection of best model
    model_list = ["RANDOM FOREST","RIDGE REGRESSION","ELASTIC NET","XGBOOST","SVR"]

    # model_list = ["RANDOM FOREST"]
    metrics = {"MAPE": "ascending"}

    result = model_train(
        df,
        para,
        lag_order,
        model_config_path,
        drop_cols,
        ts_cols,
        target,
        model_list,
        metrics,
        selectedFeature,
    )
