## Feature Selected for training
|    | Feature Name                      | Required   |
|---:|:----------------------------------|:-----------|
|  0 | FS Nuggets Servings               | False      |
|  1 | FS Breaded Chick Sandwich         | False      |
|  2 | FS Strips Servings                | False      |
|  3 | Wholesale Beef Price (USDA)       | True       |
|  4 | Pop                               | False      |
|  5 | Operator Count                    | False      |
|  6 | CR BSB Availability               | True       |
|  7 | K12 Enrollment                    | False      |
|  8 | College Enrollment                | False      |
|  9 | Retail Store Count                | True       |
| 10 | Retail BSB Promotion              | True       |
| 11 | Time Series                       | False      |
| 12 | BSB_p                             | False      |
| 13 | Comm FS Breast Price_Lag_0        | True       |
| 14 | Comm FS Breast Price_Lag_1        | False      |
| 15 | All Pork Chops Retail Price_Lag_0 | True       |
| 16 | All Pork Chops Retail Price_Lag_1 | True       |
| 17 | Breast LTOS FS_Lag_0              | False      |
| 18 | Breast LTOS FS_Lag_1              | False      |
| 19 | BSB Inventory_Lag_0               | False      |
| 20 | BSB Inventory_Lag_1               | True       |
| 21 | Comm FS Breast Sales_Lag_0        | False      |
| 22 | Comm FS Breast Sales_Lag_1        | False      |
| 23 | Ground Beef Retail Price_Lag_0    | False      |
| 24 | Ground Beef Retail Price_Lag_1    | False      |
| 25 | Jumbo BSB Availability_Lag_0      | False      |
| 26 | Jumbo BSB Availability_Lag_1      | False      |
| 27 | RDPI_Lag_0                        | True       |
| 28 | RDPI_Lag_1                        | False      |
| 29 | Retail Beef Features_Lag_0        | False      |
| 30 | Retail Beef Features_Lag_1        | False      |
| 31 | Retail Pork Features_Lag_0        | False      |
| 32 | Retail Pork Features_Lag_1        | False      |
| 33 | Traffic_Lag_0                     | False      |
| 34 | Traffic_Lag_1                     | False      |
| 35 | UB Coarse Ground 73% (770)_Lag_0  | False      |
| 36 | UB Coarse Ground 73% (770)_Lag_1  | False      |
| 37 | Unemployment_Lag_0                | False      |
| 38 | Unemployment_Lag_1                | True       |
| 39 | USDA Pork Wholesale_Lag_0         | False      |
| 40 | USDA Pork Wholesale_Lag_1         | False      |
| 41 | USDA Retail BSB Price_Lag_0       | True       |
| 42 | USDA Retail BSB Price_Lag_1       | True       |